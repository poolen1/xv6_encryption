#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

void caesarCipher(int shift, int readId, char * buf);
void vigCipher(char * keyword, int shift, int readId, char * buf, char TR[54][54], int passLen);

int main(int argc, char * argv[])
{
	char * buf;
	char * dBuf;
	struct stat sBuf;
	int openId = open(argv[1], O_RDWR);
	fstat(openId, &sBuf);
	uint fSize = sBuf.size;
	buf = malloc(fSize);
	int readId = read(openId, buf, fSize);
	int passLen;
	char crypType;
	//int passSize;
	int shiftVal;
	//int dBufSize;
	char tabulaRecta[54][54];
	char * passRead;
	char * passCheck;
	int i=0;
	int j=0;

	
	while (buf[i] != ' '){
		i++;
	}
	passLen = i;
	//passSize = sizeof(passLen);
	//dBufSize = fSize - passSize;
	//dBufSize++;
	char password[passLen-1];

	/*
	printf(1, "fSize: %d\n", fSize);
	printf(1, "passSize: %d\n", passSize);
	printf(1, "dBufSize: %d\n", dBufSize);
	*/

	crypType = buf[0];

	i=1;
	j=0;
	while (buf[i] != ' '){
		password[j] = buf[i];
		i++;
		j++;
	}
	i++;

	caesarCipher(3, passLen-1, password);

	printf(1, "Enter password: ");
	passRead = malloc(256);
	i=0;
	while (read(0, &passRead[i], 1)){
		if(passRead[i] == '\n'){
			break;
		} else
			i++;
	}
	i=0;
	passLen = strlen(passRead);
	passCheck = malloc(passLen * sizeof(char));
	passLen--;
	for (i=0; i<passLen; i++){
		passCheck[i] = passRead[i];
	}

	if (strcmp(password, passCheck)){
		printf(1, "Invalid Password. Exiting.\n");
		exit();
	}

	//printf(1, "passCheck: %s\n", passCheck);
//	printf(1, "password: %s\n", password);
	//printf(1, "strLen: %d\n", passLen);
	//printf(1, "i: %d\n", i);
	dBuf = malloc(fSize);

	i += 2;
	j=0;
	for(; i<fSize; i++){
		dBuf[j] = buf[i];
		j++;
	}

	shiftVal = password[0];
	shiftVal = shiftVal % 10;
	if (shiftVal == 0){
		shiftVal = 3;
	}
	
	/*
	printf(1, "password: %s\n", password);
	printf(1, "shiftVal: %d\n", shiftVal);
	printf(1, "passLen: %d\n", passLen);
	*/

	//Populate Tabula Recta
	j=0;
	for (i=0; i<26; i++){
		tabulaRecta[0][i] = 'A' + i;
	}
	for (i=26; i<52; i++){
		tabulaRecta[0][i] = 'a' + j;
		j++;
	}
	for (i=1; i<52; i++){
		tabulaRecta[i][51] = tabulaRecta[i-1][0];
		for (j=0; j<51; j++){
			tabulaRecta[i][j] = tabulaRecta[i-1][j+1];
		}
	}

	//TEST
	/*
	for (i=0; i<54; i++){
		for (j=0; j<54; j++){
			printf(1, "%c", tabulaRecta[i][j]);
		}
		printf(1, "\n");
	}
	*/

	if (crypType == '0'){
		caesarCipher(shiftVal, readId, dBuf);
		/*
		if (write(openId, buf, readId) != readId){
			printf(1, "write error\n");
		}
		*/
		close(openId);
	}

	else if (crypType == '1'){
		vigCipher(passCheck, shiftVal, readId, dBuf, tabulaRecta, passLen);
		close(openId);
	}

	unlink(argv[1]);
	openId = open(argv[1], O_CREATE | O_RDWR);

	write(openId, dBuf, readId - (passLen + 1));

	exit();
} 

void caesarCipher(int shift, int readId, char * buf)
{
	int i = 0;
	for (i=0; i<readId; i++){
		if (buf[i] != '\n'){
			buf[i] = buf[i] - shift;
		} 
	}
}

void vigCipher(char * keyword, int shift, int readId, char * buf, char TR[54][54], int passLen)
{
	int i;
	int j = 0;
	int row = 0;
	int col = 0;
	char key[readId];

	//TEST
	/*
	for (i=0; i<54; i++){
		for (j=0; j<54; j++){
			printf(1, "%c", TR[i][j]);
		}
		printf(1, "\n");
	}
	*/

	passLen = passLen;// - 1;
	readId = readId-9;

	//printf(1, "shift: %d\n", shift);
	//printf(1, "readId: %d\n", readId);
	//printf(1, "passLen: %d\n", passLen);

	/*
	for (i=0; i<passLen; i++){
		printf(1, "%c", keyword[i]);
	}
	*/

	for (i=0; i<readId; i++){
		if((buf[i] >= 'A' && buf[i] <= 'Z') || (buf[i] >= 'a' && buf[i] <= 'z')){
			key[i] = keyword[j];
			j++;
			if (j == passLen){
				j=0;
			}
		} else 
			(key[i] = buf[i]);
	}

	/*	
	for (i=0; i<readId; i++){
		printf(1, "%c", key[i]);
	}
	*/
	

	//printf(1, "Trap test\n");

	for (i=0; i<readId; i++){
		if (buf[i] != '\n'){
			//printf(1, "%c%c", key[i], buf[i]);
			if((buf[i] >= 'A' && buf[i] <= 'Z') || (buf[i] >= 'a' && buf[i] <= 'z')){
				while (key[i] != TR[row][0]){
					//printf(1, "%c", key[i]);
					row++;
				}
				while (buf[i] != TR[row][col]){					
					col++;
				}
				buf[i] = TR[0][col];
			} /*else {
				buf[i] = buf[i] - shift;
			}*/
		}
		row = 0;
		col = 0;
	}
}

//test
//printf(1, "readId: %d\n", readId);

	//int outputId = open("output.txt", O_RDWR);

	//TEST
	//int i = 0;
	//int lfCount = 0;
	/*
	for (i=0; i<readId; i++){
		printf(1, "%c", buf[i]);
		lfCount++;
		if (lfCount == 100)
			printf(1, "\n");
	}
	*/