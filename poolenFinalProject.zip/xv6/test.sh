echo Text to be encrypted:
cat input.txt
echo
echo Running Caesar Cipher encryption!
encrypt input.txt 0
echo 
echo Encrypted text:
cat input.txt
echo
echo Decrypting Caesar Cipher!
decrypt input.txt
echo
echo Decrypted text:
cat input.txt
echo
echo Running Vigenere Cipher encryption!
encrypt input.txt 1
echo
echo Encrypted text:
cat input.txt
echo Decrypting Vigenere Cipher!
decrypt input.txt
echo
echo Decrypted text:
cat input.txt