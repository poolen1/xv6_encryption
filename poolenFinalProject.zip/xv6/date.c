#include "types.h"
#include "stat.h"
#include "user.h"
#include "date.h"

int main(int argc, char *argv[])
{
	struct rtcdate timeDate;
	
	getDate(&timeDate);

	int second = timeDate.second;
	int minute = timeDate.minute;
	int hour = timeDate.hour;
	int day = timeDate.day;
	int month = timeDate.month;
	int year = timeDate.year;

	int leap = 0;

	if (year%4 == 0)
		leap = 1;

	//(!strcmp(argv[1], "0") || !strcmp(argv[1], "1"))

	if (argc == 1){
		printf(0, "The date is: %d:%d:%d on %d/%d/%d\n", hour,\
		 minute, second, month, day, year);
	} else if (argc == 2){
	 	if (!strcmp(argv[1], "0")){
	 		printf(0, "The date is: %d:%d:%d on %d/%d/%d\n", hour,\
			 minute, second, month, day, year);
	 	} else if (!strcmp(argv[1], "1")){
	 		if (hour == 0){
	 			hour = 12;
	 			printf(0, "The date is: %d:%d:%d AM on %d/%d/%d\n", hour,\
			 	 minute, second, month, day, year);
	 		} else if (hour < 12){
	 			printf(0, "The date is: %d:%d:%d AM on %d/%d/%d\n", hour,\
			 	 minute, second, month, day, year);
	 		} else if (hour >= 12){
	 			hour -= 12;
	 			printf(0, "The date is: %d:%d:%d PM on %d/%d/%d\n", hour,\
			 	 minute, second, month, day, year);
	 		}
	 	} else {
	 			printf(0, "Error: Flag bit unrecognized\n");
	 			exit();
	 		}
	} else if (argc == 3 && !strcmp(argv[1], "-t")){
		char sign = argv[2][0];
		int len = strlen(argv[2]);

		//char to int
		int tens;
		int ones;
		int timeZone = 0;

		//TEST
		//printf(0, "Sign: %c\n", sign);

		if (sign != '+' && sign != '-'){
			printf(0, "Error: incorrect timezone format\n");
			printf(0, "Example: -8 or +2\n");
			exit();
		} 
		if (len > 3){
			printf(0, "Error, timezone does not exist.\n");
			exit();
		} 
		if (len == 3){
			tens = argv[2][1] - '0';
			tens *= 10;
			ones = argv[2][2] - '0';
			timeZone = tens + ones;
			if (sign == '-')
				timeZone *= -1;
		} else if (len ==2){
			timeZone = argv[2][1] - '0';
			if (sign == '-')
				timeZone *= -1;
		} else{
			printf(0, "Error: incorrect timezone format\n");
			exit();
		}
		if (timeZone < -12 || timeZone > 14){
			printf(0, "Error, timezone does not exist.\n");
			exit();
		}
		//Adjust time for timeZone
		hour += timeZone;
		if (hour >= 24){
			hour -= 24;
			day++;
			if (month == 2 && day == 29 && leap == 0){
				month++;
				day = 1;
			} else if (month == 2 && day == 30 && leap == 1){
				month++;
				day = 1;
			} else if ((month == 1 || month == 3 || month == 5\
				|| month == 7 || month == 8 || month == 10)\
				 && day == 32){
				month++;
				day = 1;
			} else if ((month == 4 || month == 6 || month == 9\
				|| month == 11) && day == 31){

			} else if (month == 12 && day == 32){
				day = 1;
				month = 1;
				year++;
			}
		} else if (hour < 0){
			hour += 24;
			day--;
			if (month == 3 && day < 0){
				day = 28;
				month = 2;
			} else if ((month == 5 || month == 7 || month == 10\
				|| month == 12) && day < 0){
				month--;
				day = 30;
			} else if ((month == 2 || month == 4 || month == 6\
			 || month == 9 || month == 12) && day < 0){
				month--;
				day = 31;
			} else if (month == 1 && day < 0){
				day = 31;
				month = 12;
				year--;
			}
		}

		printf(0, "The date is: %d:%d:%d on %d/%d/%d\n", hour,\
		 minute, second, month, day, year);
		exit();

	} else if (argc == 4 && !strcmp(argv[2], "-t")){
		char sign = argv[3][0];
		int len = strlen(argv[3]);

		//char to int
		int tens;
		int ones;
		int timeZone = 0;

		//TEST
		//printf(0, "Sign: %c\n", sign);

		if (sign != '+' && sign != '-'){
			printf(0, "Error: incorrect timezone format\n");
			printf(0, "Example: -8 or +2\n");
			exit();
		}

		if (len > 3){
			printf(0, "Error, timezone does not exist.\n");
			exit();
		}

		if (len == 3){
			tens = argv[3][1] - '0';
			tens *= 10;
			ones = argv[3][2] - '0';
			timeZone = tens + ones;
			if (sign == '-')
				timeZone *= -1;
		} else if (len ==2){
			timeZone = argv[3][1] - '0';
			if (sign == '-')
				timeZone *= -1;
		} else{
			printf(0, "Error: incorrect timezone format\n");
			exit();
		}
		if (timeZone < -12 || timeZone > 14){
			printf(0, "Error, timezone does not exist.\n");
			exit();
		}
		//Adjust time for timeZone
		hour += timeZone;
		if (hour >= 24){
			hour -= 24;
			day++;
			if (month == 2 && day == 29 && leap == 0){
				month++;
				day = 1;
			} else if (month == 2 && day == 30 && leap == 1){
				month++;
				day = 1;
			} else if ((month == 1 || month == 3 || month == 5\
				|| month == 7 || month == 8 || month == 10)\
				 && day == 32){
				month++;
				day = 1;
			} else if ((month == 4 || month == 6 || month == 9\
				|| month == 11) && day == 31){

			} else if (month == 12 && day == 32){
				day = 1;
				month = 1;
				year++;
			}
		} else if (hour < 0){
			hour += 24;
			day--;
			if (month == 3 && day < 0){
				day = 28;
				month = 2;
			} else if ((month == 5 || month == 7 || month == 10\
				|| month == 12) && day < 0){
				month--;
				day = 30;
			} else if ((month == 2 || month == 4 || month == 6\
			 || month == 9 || month == 12) && day < 0){
				month--;
				day = 31;
			} else if (month == 1 && day < 0){
				day = 31;
				month = 12;
				year--;
			}
		}

		if (!strcmp(argv[1], "0")){
	 		printf(0, "The date is: %d:%d:%d on %d/%d/%d\n", hour,\
			 minute, second, month, day, year);
	 	} else if (!strcmp(argv[1], "1")){
	 		if (hour == 0){
	 			hour = 12;
	 			printf(0, "The date is: %d:%d:%d AM on %d/%d/%d\n", hour,\
			 	 minute, second, month, day, year);
	 		} else if (hour < 12){
	 			printf(0, "The date is: %d:%d:%d AM on %d/%d/%d\n", hour,\
			 	 minute, second, month, day, year);
	 		} else if (hour > 12){
	 			hour -= 12;
	 			printf(0, "The date is: %d:%d:%d PM on %d/%d/%d\n", hour,\
			 	 minute, second, month, day, year);
	 		} else if (hour == 12){
	 			printf(0, "The date is: %d:%d:%d PM on %d/%d/%d\n", hour,\
			 	 minute, second, month, day, year);
	 		}
	 	} else {
	 			printf(0, "Error: Flag bit unrecognized\n");
	 			exit();
	 		}

	} else
		printf(0, "Usage: date [Optional: 12/25hr flag] [Optional: -t TIMEZONE]\n1 for 12 hour, 0 for 24 hour\n");

	//TEST 
	/*
	printf(0, "Seconds: %d\n", seconds);
	printf(0, "Minute: %d\n", minute);
	printf(0, "hour: %d\n", hour);
	printf(0, "day: %d\n", day);
	printf(0, "month: %d\n", month);
	printf(0, "year: %d\n", year);
	*/

	exit();
}