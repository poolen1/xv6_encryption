#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  myproc() -> sz += n;
  /*
  if(growproc(n) < 0)
    return -1;
    */
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

// return time since program began
int
sys_time(void)
{
  return 0;
}

// return time and date
int
sys_getDate(void)
{
  int arg;
  struct rtcdate * timeDate;

  arg = argptr(0, (char**)&timeDate, 6);
  //arg = (int*)timeDate;
  if (arg < 0)
    return -1;
  else{
    cmostime(timeDate);
  }
  return 0;
}

// return process time spent in IO
int
sys_IOTime(int time)
{
  //int time;

  if (argint(0, &time) < 0)
    return -1;
  else
    updateIOTime(time);

  //test
  //cprintf("time: %d\n", time);

  return 0;
}

// return waitTime
// return creationTime, startTime, runTime, ioTime, endTime
//  by reference
int
sys_wait2(void)
{
  int * creationTime;
  int * startTime;
  int * runTime;
  int * ioTime;
  int * endTime;
  int * tickets;

  argptr(0, (char**)&creationTime, sizeof(int));
  argptr(1, (char**)&startTime, sizeof(int));
  argptr(2, (char**)&runTime, sizeof(int));
  argptr(3, (char**)&ioTime, sizeof(int));
  argptr(4, (char**)&endTime, sizeof(int));
  argptr(5, (char**)&tickets, sizeof(int));

  return getProcessStats(creationTime, startTime, runTime, ioTime, endTime, tickets);
}

// fork, plus tickets for lottery scheduler
int
sys_fork2(int * tickets)
{
  //int * tickets;

  argptr(0, (char**)&tickets, sizeof(int));

  //test
  /*
  int randVal = rand();
  cprintf("randVal: %d\n", randVal);
  */
  //cprintf("fork2 tickets: %d\n", *tickets);

  return getTickets(tickets);
}

//encryption
int
sys_encrypt(void)
{
  return 0;
}

//decryption
int
sys_decrypt(void)
{
  return 0;
}