#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int main(int argc, char *argv[])
{
	char buf[512];
	int openId = open(argv[1],O_RDONLY);
	int readId = read(openId, buf, 512);
	//close(openId);
	
	//TEST
	//printf(1, "script readId: %d\n", readId);

	if (!strcmp(argv[2], "1") || !strcmp(argv[2], "01")){
		int i = 0;
		for (i=0; i<readId; i++){
			printf(1, "%c", buf[i]);
		}
		printf(1, "\n");
	}

	char * myArgv[32]; //= {"echo", "Hello", "World!", 0};
	
	char * arg;		//string var
	int i = 0;			//buffer char count
	int j = 0;			//string var char count
	int count = 0;		//arg count in myArgv
	while (i<(readId-2)){

		arg = malloc(32 * sizeof(char));

		//printf(1,"begin\n");
		j=0;
		
		//TEST
		//printf(1,"buf[i]: %c\n",buf[i]);
		
		if (buf[i] == '\n'){
			memset(myArgv, 0, 32*sizeof(char));
			i++;
			count = 0;
		}
		//TEST
		/*
		int k;
		for (k=0; k<=count; k++){
			printf(1,"cleared myArgv[%d]: %s \n", k, myArgv[k]);
		}
		*/
		
		while (buf[i] != ' ' && buf[i] != '\n' && buf[i] != 0){
			if (buf[i] == 13){
				i++;
				j++;
				continue;
			}
			arg[j] = buf[i];
			j++;
			i++;
		}

		//TEST
		//printf(1,"arg: %s\n", arg);
		//printf(1,"j: %d\n",j);
		//printf(1,"i: %d\n",i);
		//printf(1,"count: %d\n",count);
		//myArgv[count] = arg;
		//count++;
		if (buf[i] == ' '){
			//printf(1,"buf[i]=' '\n");
			//arg = malloc(32 * sizeof(char));
			myArgv[count] = arg;

			//TEST
			//printf(1,"myArgv[0]: %s\n",myArgv[0]);
			/*
			int k;
			for (k=0; k<count; k++){
				printf(1,"myArgv[%d]: %s \n", k, myArgv[k]);
			}
			*/

			/*
			int k;
			for (k=0; k<32; k++)
				arg[k] = '\0';
				*/
				
			//memset(arg, '\0', sizeof(32));
			i++;
			count++;
			continue;
		}
		else if (buf[i] == '\n' || buf[i] == 0){
			myArgv[count] = arg;

			//TEST
			//printf(1,"myArgv[0]: %s\n",myArgv[0]);
			//printf(1,"myArgv[%d]: %s \n", count, myArgv[count]);

			//count++;
			//myArgv[count] = "0";
			//printf(1,"myArgv[0]: %s\n",myArgv[0]);
			//printf(1,"myArgv[%d]: %s \n", count, myArgv[count]);
			int pid = fork();

			if (pid > 0) {
				pid = wait();
			} else if (pid == 0) {
				//close(0);

				//TEST
				/*
				for (k=0; k<=count; k++){
					printf(1,"myArgv[%d]: %s \n", k, myArgv[k]);
				}
				*/

				exec(myArgv[0], myArgv);
				//printf(1,"exec error\n");
				//exit();

				/*
				int k;
				for (k=0; k<32; k++)
					myArgv[k];
					*/
					
					

				//memset(arg, '\0', sizeof(32));
				i++;
				count = 0;
				//j = 0;
				continue;
			} else {
				printf(1, "fork error\n");
			}
		}
	}

	//TEST
	/*
	printf(1, "openId: %d\n", openId);
	printf(1, "readId: %d\n", readId);
	printf(1,"This is a sample\n");
	printf(1,"%s\n", argv[1]);
	*/

	exit();
}