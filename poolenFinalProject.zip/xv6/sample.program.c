#include "types.h"
#include "stat.h"
#include "user.h"

int main(void)
{
	int pid;

	pid = fork();
	if (pid > 0){
		printf("parent: child=%d\n", pid);
		pid = wait();
		printf("child %d id done\n", pid);
	} else if (pid == 0){
		printf("child: exiting\n");
		exit();
	} else{
		printf("fork error\n");
	}

	exit();
}