#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int main(int argc, char * argv[])
{
	const int CPU_ITERATIONS = 10000000;

	char buf[512];
	int openId = open(argv[1], O_RDONLY);
	//int readId = read(openId, buf, 512);
	int readId = read(openId, buf, 512);

	char procs;	//process count, char
	int procc;	//process count, int
	int myProcv[64][10]; //process data vector
	int CPUbursts;
	int IObursts;
	int totalBursts;
	char myStr[32];	//string to read into from buffer
	int arrivalTime[32];
	int ticketCount[32];

	int sTime; 		//proc start time
	int currTime; 	//current time
	int pid;		//process id
	int counter;	//"ticks" counter

	
	int creationTime = 0;
	int startTime = 0;
	int runTime = 0;
	int ioTime = 0;
	int endTime = 0;
	int waitTime = 0;
	int TAT = 0;		//Turn-around Time
	int response = 0;	//response time
	int avgTAT = 0;
	int avgResponse = 0;
	int tickets = 0;
	

	//buffer counter
	int i=0;
	procs = buf[i];
	procc = procs -'0';
	procc = procc;
	int pids[procc];
	int procStats[procc][8];
	

	i=2; //buffer char count
	int j=0; //myStr count
	int k=0; //proc count;
	int l=0; //myProcv arg count;
	int arrFlag=1; //arrivalTime flag
	int tickFlag=0;

	//read-in loop
	while (i<readId){
		if (buf[i] != ' ' && buf[i] != '\n'){
			myStr[j] = buf[i];

			//test
			//printf(1, "buf[%d]: %c\n", i, buf[i]);
			//printf(1, "myStr[%d]: %c\n", j, myStr[j]);
			//printf(1, "myStr: %s\n", myStr);
			
			i++;
			j++;
		} else if (buf[i] == ' '){
			//myProcv[k][l] = atoi(myStr);
			if (arrFlag==1){
				arrivalTime[k] = atoi(myStr);
				
				memset(myStr, 0, 32 * sizeof(char));
				i++;
				j=0;
				arrFlag = 2;
			}  else if (tickFlag==1){
				ticketCount[k] = atoi(myStr);

				//test
				//printf(1, "ticketCount[%d]: %d\n", k, ticketCount[k]);
				//printf(1, "arrivalTime[%d]: %d\n", k, arrivalTime[k]);
				
				memset(myStr, 0, 32 * sizeof(char));
				i++;
				j=0;
				arrFlag = 0;
				tickFlag = 0;
			}  else {
				myProcv[k][l] = atoi(myStr);
				memset(myStr, 0, 32 * sizeof(char));
				i++;
				j=0;
				l++;
			}

			if (arrFlag==2){
				tickFlag = 1;
				arrFlag = 0;
			}
				/*
			memset(myStr, 0, 32 * sizeof(char));
			i++;
			j=0;
			l++;*/
		} else if (buf[i] == '\n' || buf[i] == 0){
			/*if (arrFlag==1){
				arrivalTime[k] = atoi(myStr);
				arrFlag = 0;
			} else {*/
				myProcv[k][l] = atoi(myStr);
			//}

			//test
			/*
			int m;
			int n;
			for (m=0; m<=k; m++){
				for (n=0; n<=l; n++)
					printf(1, "myProcv[%d][%d]: %d\n", m, n, myProcv[m][n]);
			}
			*/
			
			
			/*
			CPUbursts = myProcv[k][1];
			IObursts = CPUbursts - 1;
			totalBursts = CPUbursts + IObursts;
			*/

			//test
			//printf(1, "CPUbursts: %d\n", CPUbursts);
			//printf(1, "IObursts: %d\n", IObursts);
			//printf(1, "totalBursts: %d\n", totalBursts);

			//memset(myProcv, 0, 11 * sizeof(int));
			memset(myStr, 0, 32 * sizeof(char));
			i++;
			j=0;
			k++;
			l=0;
			
			arrFlag = 1;
			tickFlag = 0;
			
		}
	}

	//test
	//printf(1, "totalBursts: %d\n", totalBursts);
	
	/*
	int q;
	for (q=0; q<procc; q++){
		printf(1, "ticketCount[%d]: %d\n", q, ticketCount[q]);
	}
	*/
	
	/*
	int m;
	int n;
	for (m=0; m<procc; m++){
		CPUbursts = myProcv[m][0];
		IObursts = CPUbursts - 1;
		totalBursts = CPUbursts + IObursts;
		//printf(1, "totalBursts: %d\n", totalBursts);
		printf(1, "arrivalTime[%d]: %d\n", m, arrivalTime[m]);
		printf(1, "myProcv[%d]: ", m);
		for (n=0; n<=totalBursts; n++)
			printf(1,"%d ", myProcv[m][n]);
		printf(1, "\n");
	}
	*/

	//parent process
	sTime = uptime();
	int sleepTime = 0;
	//int l=0;
	//test
	//printf(1, "uptime: %d\n", sTime);

	//i: process count
	//j: 
	//k:
	for (i=0; i<procc; i++){
	//for (i=procc-1; i>=0; i--){
		currTime = uptime();
		sleepTime = arrivalTime[i] - (currTime - sTime);
		CPUbursts = myProcv[i][0];
		IObursts = CPUbursts - 1;
		totalBursts = CPUbursts + IObursts;

		//test
		//printf(1, "sleepTime: %d\n", sleepTime);
		//printf(1, "totalBursts: %d\n", totalBursts);
		
		if (arrivalTime[i] > (currTime - sTime)){
			sleep(sleepTime);
		}

		//test
		//printf(1, "ticketCount[%d]: %d\n", i, ticketCount[i]);

		pid = fork2(&ticketCount[i]);
		
		/*if (pid > 0){
			pids[i] = wait2(&creationTime, &startTime, &runTime, &ioTime, &endTime);
		} else*/ if (pid == 0){
			//child process
			counter = 0;
			pid = getpid();
			//perform cpu burst

			//test
			//printf(1, "zombie 1\n");

			//j: ticks counter
			for (j=0; j<(myProcv[i][1] * CPU_ITERATIONS); j++){
				counter++;
			}

			
			if (totalBursts == 1){
				//printf(1, "1 CPU burst\n");
				exit();
			}
			

			//test
			//printf(1, "zombie 2\n");
			//printf(1, "totalBursts: %d\n", totalBursts);

			//j: iterate through total bursts
			for (j=2; j<totalBursts; j++){
			//for (j=totalBursts-1; j>=2; j--){
				//next burst is I/O burst
				for (k=0; k<myProcv[i][j]; k++){
					printf(1, "child %d prints for the %d time\n", pid, k+1);
				}

				//test
				//printf(1, "zombie 3\n");

				j++;
				//j--;
				//next burst is CPU burst
				for (k=0; k<(myProcv[i][j] * CPU_ITERATIONS); k++){
					counter++;
				}

				//test
				//printf(1, "zombie 4\n");
				/*
				if (totalBursts == 1){
					printf(1, "1 CPU burst\n");
				}
				*/

			}
			exit();
		}
	}
	for (i=0; i<procc; i++){
		creationTime = 0;
		startTime = 0;
		runTime = 0;
		ioTime = 0;
		endTime = 0;
		waitTime = 0;
		TAT = 0;		//Turn-around Time
		response = 0;	//response time
		tickets = 0;
		//int avgTAT = 0;
		//int avgResponse = 0;

		pids[i] = wait2(&creationTime, &startTime, &runTime, &ioTime, &endTime, &tickets);
		
		//test
		//printf(1, "pids[%d]: %d\n", i, pids[i]);

		//store times for process
		procStats[i][0] = creationTime;
		procStats[i][1] = startTime;
		procStats[i][2] = endTime;
		procStats[i][3] = runTime;
		procStats[i][4] = ioTime;
		//calculate waitTime, TAT and Response
		waitTime = endTime - creationTime-runTime-ioTime;
		TAT = endTime - creationTime;
		response = startTime - creationTime;
		procStats[i][5] = waitTime;
		procStats[i][6] = TAT;
		procStats[i][7] = response;

		avgTAT += procStats[i][6];
		avgResponse += procStats[i][7];
	
		//test
		//printf(1, "tickets: %d\n", tickets);
	}
	for (i=0; i<procc; i++){
		//print process timing information
		printf(1, "child[%d]: cTime - %d sTime - %d eTime - %d\n rTime - %d ioTime - %d wTime - %d\n turnaround time - %d response time - %d\n", pids[i], procStats[i][0], procStats[i][1], procStats[i][2], procStats[i][3], procStats[i][4], procStats[i][5], procStats[i][6], procStats[i][7]);
	}
	//print avg TAT and avg Response
	avgTAT = avgTAT/procc;
	avgResponse = avgResponse/procc;
	printf(1, "Avg TAT: %d\n", avgTAT);
	printf(1, "Avg Response: %d\n", avgResponse);


	exit();
}
