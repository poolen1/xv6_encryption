echo Hello World!
echo Running Tests Script!
sample_program
echo Making directory: myDir
mkdir myDir
ls
rm myDir
echo Exiting Test Script!
