#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[])
{
	//int i;
	int startTime = 0;
	int endTime = 0;
	int totalTime = 0;	//total time in ticks
	int secMode = 0;	//0 returns ticks, 1 returns seconds
	int seconds = 0;	//total time in seconds


	int i = 0;
	if (!strcmp(argv[1], "-s")){
		secMode = 1;
		i = 0;
		for (i=0; i<argc; i++){
			argv[i] = argv[i+2];
		}
		argv[argc-2] = 0;
	}
	else{
		i = 0;
		for (i=0; i<argc; i++){
			argv[i] = argv[i+1];
		}
		argv[argc-1] = 0;
	}

	//TEST
	/*
	i = 0;
	while (argv[i] != 0){
		printf(1, "Arg %d: %s\n", i, argv[i]);
		i++;
	}
	printf(1, "secMode: %d\n", secMode);
	*/

		int pid = fork();

		if (pid > 0){
			endTime = 0;
			startTime = uptime();
			
			pid = wait();
			
			endTime = uptime();
			totalTime = endTime - startTime;
			if (secMode == 0){
				printf(1, "real time in ticks: %d ticks\n", totalTime);
			} else if (secMode == 1){
				if (totalTime < 10){
					//TEST
					//printf(1, "real time in ticks: %d ticks\n", totalTime);

					printf(1, "real time in seconds: 0.0%d seconds\n", totalTime);
				}
				else if (totalTime < 100){
					//TEST
					//printf(1, "real time in ticks: %d ticks\n", totalTime);

					printf(1, "real time in seconds: 0.%d seconds\n", totalTime);
				} else{
					//TEST
					//printf(1, "real time in ticks: %d ticks\n", totalTime);

					seconds = totalTime/100;
					seconds = seconds * 100;
					totalTime = totalTime - seconds;
					seconds = seconds/100;
					printf(1, "real time in seconds: %d.%d seconds\n", seconds, totalTime);
				}
			}
		} else if (pid == 0){
			//TEST
			/*
			printf(1, "Command: %s\n", argv[0]);
			i = 0;
			while (argv[i] != 0){
				printf(1, "Arg %d: %s\n", i, argv[i]);
				i++;
			}
			*/

			exec(argv[0], argv);
			//endTime = uptime();
		} else {
			printf(1, "fork error\n");
		}
	//}

	exit();
}